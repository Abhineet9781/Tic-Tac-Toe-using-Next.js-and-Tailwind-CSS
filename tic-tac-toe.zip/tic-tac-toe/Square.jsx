import React from 'react'

export const Square = (props) => {
    return (
        <div className="border border-black w-[100px] h-[100px] flex justify-center items-center " onClick={props.onClick}>
            <h5 className="text-black ">{props.value}</h5>
        </div>
    )
}
